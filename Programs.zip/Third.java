import java.util.Scanner;

public class Third {

	public static void main(String[] args) {
		int a,b;
		Scanner sc = new Scanner(System.in);
		a=sc.nextInt();
		b=sc.nextInt();
		System.out.println("Before swapping : a, b = "+a+", "+ + b);
			  
			  a = a + b;  
			  b = a - b;  
			  a = a - b;  
			  System.out.println("After swapping : a, b = "+a+", "+ + b);

	}

}
