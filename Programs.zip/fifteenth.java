
public class LastIndexOfExample{  
public static void main(String args[]){  
String s1="The quick brown fox jumps over the lazy dog.";  
int index1=s1.lastIndexOf('s');  
System.out.println(index1);
}}  

public class LengthofString {  
public static void main(String args[]){  
String s1="The quick brown fox jumps over the lazy dog.";  
int index1=s1.length();  
System.out.println(index1);
}}  

public class Colorado {
    
	  public static void main(String[] args)
	    {
	        String str1 = "Shanghai Houston Colorado Alexandria";
	        String str2 = "Alexandria Colorado Houston Shanghai";
	        boolean match1 = str1.regionMatches(0, str2, 28, 8);
	        boolean match2 = str1.regionMatches(9, str2, 9, 8);

	        System.out.println("str1[0 - 7] == str2[28 - 35]? " + match1);
	        System.out.println("str1[9 - 15] == str2[9 - 15]? " + match2);
	    }
	}

public class Exercise24 {
    
	   public static void main(String[] args)
	    {
	        String str = "The quick brown fox jumps over the lazy dog.";

	        // Replace all the 'd' characters with 'f' characters.
	        String new_str = str.replace('d', 'f');

	        // Display the strings for comparison.
	        System.out.println("Original string: " + str);
	        System.out.println("New String: " + new_str);
	    }
	}



public class Exercise25 {
    
	   public static void main(String[] args)
	    {
	        String str = "The quick brown fox jumps over the lazy dog.";

	         // Replace all the 'dog' with 'cat'.
	        String new_str = str.replaceAll("fox", "cat");
	       
	         // Display the strings for comparison.
	        System.out.println("Original string: " + str);
	        System.out.println("New String: " + new_str);
	    }
	}



public class Exercise26 {
    
	   public static void main(String[] args)
	    {
	        String str1 = "Red is favorite color.";
	        String str2 = "Orange is also my favorite color.";

	        // The String to check the above two Strings to see
	        // if they start with this value (Red).
	        String startStr = "Red";

	        // Do either of the first two Strings start with startStr?
	        boolean starts1 = str1.startsWith(startStr);
	        boolean starts2 = str2.startsWith(startStr);

	        // Display the results of the startsWith calls.
	        System.out.println( str1 + " starts with " +
	             startStr + "? " + starts1);
	        System.out.println(str2 + " starts with " +
	             startStr + "? " + starts2);
	    }
	}