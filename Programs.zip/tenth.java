import java.util.Scanner;

public class tenth {

	public static void main(String[] args) {
		int n;
		 Scanner sc = new Scanner(System.in);
	        n = sc.nextInt() ;
	        System.out.println("Enter the no. of elements in array");  
	        int[] array = new int[n];  
	        System.out.println("Enter the elements of the array: ");  
	        for(int i=0; i<n; i++)  
	        {    
	        array[i]=sc.nextInt();  
	        }   
			System.out.println("Odd Numbers:");  
			for(int i=0;i<array.length;i++){  
			if(array[i]%2!=0){  
			System.out.println(array[i]);  
			}  
			}  
			System.out.println("Even Numbers:");  
			for(int i=0;i<array.length;i++){  
			if(array[i]%2==0){  
			System.out.println(array[i]);  
			}  
			}  
			 

	}
	

}
