package com.example.Stock.Service;

public interface StockService {

}
