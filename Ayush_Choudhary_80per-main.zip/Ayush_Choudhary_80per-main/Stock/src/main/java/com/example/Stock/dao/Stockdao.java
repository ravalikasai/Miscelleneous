package com.example.Stock.dao;

public interface Stockdao {

}
